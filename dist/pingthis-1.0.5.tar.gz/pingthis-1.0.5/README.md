# PingThis

**PingThis** is an internal network pinging tool designed for simplicity and usability. It provides a clean, terminal-friendly way to check the status of multiple hosts.

## Installation

Clone the repo and install the package with pip:

```bash
git clone https://github.com/eytin/pingthis.git
cd pingthis
pip install .
